document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('token');
  if (token) {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('note-app').style.display = 'block';
    loadNotes();
  } else {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'block';
    document.getElementById('note-app').style.display = 'none';
  }

  // Register
  document.getElementById('register').addEventListener('click', async () => {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;

    try {
      const response = await fetch('/api/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password })
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem('token', data.token);
        window.location.href = 'index.html';
      } else {
        alert('Error registering');
      }
    } catch (err) {
      alert('Error registering');
    }
  });

  // Login
  document.getElementById('login').addEventListener('click', async () => {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
      const response = await fetch('/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem('token', data.token);
        window.location.href = 'index.html';
      } else {
        alert('Error logging in');
      }
    } catch (err) {
      alert('Error logging in');
    }
  });

  // Logout
  document.getElementById('logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    window.location.href = 'login.html';
  });

  // Create or update note
  document.getElementById('create-note').addEventListener('click', async () => {
    const title = document.getElementById('note-title').value;
    const content = document.getElementById('note-content').value;
    const tags = document.getElementById('note-tags').value.split(',').map(tag => tag.trim());
    const color = document.getElementById('note-color').value;
    const noteId = document.getElementById('create-note').getAttribute('data-id');

    const method = noteId ? 'PUT' : 'POST';
    const url = noteId ? `/api/notes/${noteId}` : '/api/notes';

    try {
      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ title, content, tags, color })
      });
      if (response.ok) {
        loadNotes();
        clearForm();
      } else {
        alert('Error saving note');
      }
    } catch (err) {
      alert('Error saving note');
    }
  });

  // Load notes
  async function loadNotes() {
    try {
      const response = await fetch('/api/notes', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const notes = await response.json();
      const notesContainer = document.getElementById('notes');
      notesContainer.innerHTML = '';
      notes.forEach(note => {
        const noteElement = document.createElement('div');
        noteElement.className = 'note';
        noteElement.style.backgroundColor = note.color;
        noteElement.innerHTML = `
          <h2>${note.title}</h2>
          <p>${note.content}</p>
          <p>Tags: ${note.tags.join(', ')}</p>
          <button class="edit-note" data-id="${note._id}">Edit</button>
          <button class="delete-note" data-id="${note._id}">Delete</button>
        `;
        notesContainer.appendChild(noteElement);
      });

      // Add event listeners to edit and delete buttons
      document.querySelectorAll('.edit-note').forEach(button => {
        button.addEventListener('click', (e) => {
          const noteId = e.target.getAttribute('data-id');
          const note = notes.find(note => note._id === noteId);
          document.getElementById('note-title').value = note.title;
          document.getElementById('note-content').value = note.content;
          document.getElementById('note-tags').value = note.tags.join(', ');
          document.getElementById('note-color').value = note.color;
          document.getElementById('create-note').textContent = 'Update Note';
          document.getElementById('create-note').setAttribute('data-id', noteId);
        });
      });

      document.querySelectorAll('.delete-note').forEach(button => {
        button.addEventListener('click', async (e) => {
          const noteId = e.target.getAttribute('data-id');
          try {
            const response = await fetch(`/api/notes/${noteId}`, {
              method: 'DELETE',
              headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
              }
            });
            if (response.ok) {
              loadNotes();
            } else {
              alert('Error deleting note');
            }
          } catch (err) {
            alert('Error deleting note');
          }
        });
      });
    } catch (err) {
      alert('Error loading notes');
    }
  }

  // Clear form
  function clearForm() {
    document.getElementById('note-title').value = '';
    document.getElementById('note-content').value = '';
    document.getElementById('note-tags').value = '';
    document.getElementById('note-color').value = '#ffffff';
    document.getElementById('create-note').textContent = 'Create Note';
    document.getElementById('create-note').removeAttribute('data-id');
  }
});